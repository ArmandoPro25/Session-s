package mx.utng.pd.absFactory;

public abstract class VehiculoFactory {
    private static final String VEHICULO LUJO = "Lujo";
    private static final String VEHICULO ECONOMICO = "Economico";

    public abstract Lujo;
    public abstract Economico;
    }
