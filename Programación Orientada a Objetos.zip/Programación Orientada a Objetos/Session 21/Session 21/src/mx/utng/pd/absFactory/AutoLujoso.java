package mx.utng.pd.absFactory;

public class AutoLujoso implements Auto {
    private String Name;
    
    public AutoLujoso(String Name) {
        this.Name = Name;
    }

    @Override
    public String getName() {
        return  Name;
    }

    @Override
    public String getCharacteristics() {
        return "Auto con muchas caracteristicas";
    }
}

