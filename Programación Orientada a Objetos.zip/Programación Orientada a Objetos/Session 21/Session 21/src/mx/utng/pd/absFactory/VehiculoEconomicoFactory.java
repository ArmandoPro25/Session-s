package mx.utng.pd.absFactory;

public class VehiculoEconomicoFactory extends VehiculoFactory {
    //get auto y get camioneta
}
