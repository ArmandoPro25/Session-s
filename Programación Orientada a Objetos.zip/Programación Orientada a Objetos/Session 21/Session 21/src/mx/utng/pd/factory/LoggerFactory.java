package mx.utng.pd.factory;

import java.io.IOException;
import java.util.Properties;

public class LoggerFactory {
    public boolean isFileLogginEnable(){

        Properties p = new Properties();
        try {
            p.load(ClassLoader.getSystemResourceAsStream("Logger.properties"));
            String fileLogginValue = p.getProperty("FileLogging");
            if(fileLogginValue.equalsIgnoreCase("ON")==true){
                return true;
            }else{
                return false;
            }

        } catch (IOException e) {
            return false;
        }
    }
    public Logger getLogger(){
        if(isFileLogginEnable()){
        return new FileLogger();
      }else{
        return new ConsoleLogger();
}
}

public Logger gerLogger(int type){
    if(type==1){
    return new FileLogger();
}else{
    return new ConsoleLogger();
}
}
}