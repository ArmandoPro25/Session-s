package mx.utng.pd.absFactory;

public interface Auto {
   String  getName();
   String getCharacteristics();

}
