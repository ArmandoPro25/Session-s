package mx.utng.pd.absFactory;

public class CamionetaLujosa implements Camioneta {

    private String Name;
    public CamionetaLujosa(String Name){
        this.Name = Name;
    
    }
   @Override
   public String getName() {
       // TODO Auto-generated method stub
       return Name;
   }
   @Override
   public String getCharacteristics() {
       // TODO Auto-generated method stub
       return "Esta camioneta tiene muchas caracteristicas";
   }
}
