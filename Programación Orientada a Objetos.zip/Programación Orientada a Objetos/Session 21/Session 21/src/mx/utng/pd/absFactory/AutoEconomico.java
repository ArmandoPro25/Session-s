package mx.utng.pd.absFactory;

public class AutoEconomico implements Auto {
    private String Name;

    public AutoEconomico(String Name) {
        this.Name = Name;
    }

    @Override
    public String getName() {
        
        return Name;
    }
        
    
    
    @Override
    public String getCharacteristics() {

        return "Auto economico con pocas características";
    }
}
