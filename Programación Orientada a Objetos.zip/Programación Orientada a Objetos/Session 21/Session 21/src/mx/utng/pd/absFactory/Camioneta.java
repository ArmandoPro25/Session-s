package mx.utng.pd.absFactory;

public interface Camioneta {
    String  getName();
    String getCharacteristics();
 
 }