package mx.utng.s33;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/data")
public class S33RestApplication extends Application {
}
