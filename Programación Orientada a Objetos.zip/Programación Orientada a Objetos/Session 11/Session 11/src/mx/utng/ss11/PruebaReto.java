package mx.utng.ss11;

import java.time.LocalDate;

public class PruebaReto {
    public static void main(String[] args) {
        Programador programador = new Programador("Armando", 19, (2005, 1, 18), 0, null)
System.out.println(programador.toString());

        // NO LO PUDE IMPRIMIR PARA VER SI FUNCIONA :(
            //NO SUPE USAR EL LOCALDATE :(
    }
    
}
