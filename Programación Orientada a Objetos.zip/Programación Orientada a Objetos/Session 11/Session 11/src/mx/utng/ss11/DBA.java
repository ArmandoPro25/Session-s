package mx.utng.ss11;

import java.time.LocalDate;

public class DBA extends Empleado{
    
    private String herramientaConsulta;

    public DBA(String nombre, byte edad, LocalDate fechaNacimiento,
                float salario, String lenguajePrincipal, String herramientaConsulta){
    super(nombre, edad, fechaNacimiento, salario);
    this.herramientaConsulta = herramientaConsulta;

}
    //Agregamos get y set de herramienta de consultas

    public String getHerramientaConsulta() {
        return herramientaConsulta;
    }

    public void setHerramientaConsulta(String herramientaConsulta) {
        this.herramientaConsulta = herramientaConsulta;
    }

    @Override
    public String toString() {
        return super.toString() + ", Herramienta de consultas: "+ getHerramientaConsulta();
    }

}

