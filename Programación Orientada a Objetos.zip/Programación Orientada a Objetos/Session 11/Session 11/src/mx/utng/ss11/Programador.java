package mx.utng.ss11;

import java.time.LocalDate;

public class Programador extends Empleado{
    private String lenguajePrincipal;

public Programador(String nombre, byte edad, LocalDate fechaNacimiento,
                    float salario, String lenguajePrincipal) {
    super(nombre, edad, fechaNacimiento, salario);
    this.lenguajePrincipal = lenguajePrincipal;

}
// Agregamos los set y get de lenguaje principal

public void setLenguajePrincipal(String lenguajePrincipal) {
    this.lenguajePrincipal = lenguajePrincipal;
}

public String getLenguajePrincipal() {
    return lenguajePrincipal;
}

@Override

public String toString() { 
    return super.toString() + ", Lenguaje Principal: " + getLenguajePrincipal();
}

}
//Jose Armando Ruano Mascorro - GDS0624
