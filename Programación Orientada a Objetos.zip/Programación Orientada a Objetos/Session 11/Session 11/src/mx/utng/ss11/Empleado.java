package mx.utng.ss11;

import java.time.LocalDate;

public class Empleado extends Persona {
    private float salario;

public Empleado(String nombre, byte edad, LocalDate fechaNacimiento, float salario){

    super(nombre, edad, fechaNacimiento);
    this.salario = salario;
}

    //Agregamos get y set de Salario

public float getSalario() {
    return salario;
}

public void setSalario(float salario) {
    this.salario = salario;
}

@Override
public String toString() {
    return super.toString() + ", Salario: "+ getSalario();
}

}
//Jose Armando Ruano Mascorro - GDS0624