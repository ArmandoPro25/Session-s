package mx.utng.s28.persistences;

public class EquipoRepository {
    public static void main(String[] args) {
        System.out.println("Panchito es mi perrita");
    }
    
}
