package mx.utng.s28.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Equipo {
    @ID
    private Long id;
    private String nombre;

}
