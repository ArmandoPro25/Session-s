package mx.utng.ss05;

public class primitivos {
    public static void main(String[] args) {
        //Entero muy pequeño (-128 a 127)
        byte valorbyte = 10;
        System.out.println(valorbyte);
        
        //Entero corto (-32768 a 32767)
        short valorShort = 32767;
        System.out.println(valorShort);

        //  Entero base (-214783648 a 214783647)
        int valorInt = 2147483647;
        System.out.println(valorInt);

        // Entero más largo (-9223372036854775808l a 9223372036854775807l)
        long valorlong = 9223372036854775807l;
        System.out.println(valorlong);

        // Numero real tienen un punto decimal es de 6 cifras despues del punto
        float valorfloat = 7.5131231434334343f;
        System.out.println(valorfloat);

        // Numero real con doble precision es de 16 cifras despues del punto
        double valordouble = 3.1234567890126123456789123456789;
        System.out.print(valordouble);

        // Valor booleano con dos valores posibles (true/false)
        boolean valorboolean = true;

        //primitivo con texto
        char valorchar = 'B';
        System.out.printf("%nValor bolleano: %b %nValor caracter: %c%n", 
        valorboolean, valorchar);

        float numfloat = 1;
        int numint1 = (int)numfloat;
        System.out.printf("Numero Flotante: %f, Entero: %d%n", numfloat, numint1);

        char numchar = 'M';
        numchar++;
        int numInt2 = numchar;
        System.out.printf("Char: %c, Entero: %d%n", numchar, numInt2);

    }
}
