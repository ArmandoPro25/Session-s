package mx.utng.s32;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S32ApplicationTests {

	@Test
	void contextLoads() {
	}

}
