package mx.utng.s32;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S32Application {

	public static void main(String[] args) {
		SpringApplication.run(S32Application.class, args);
	}

}
