package mx.utng.s30;

public class MiHilo {
    public static void main(String[] args) {
        Thread t1 = new Thread(new Hilo1());
        Thread t2 = new Thread(new Hilo2());

        t1.start();
        t2.setDaemon(true);
        t2.start();
    }

}