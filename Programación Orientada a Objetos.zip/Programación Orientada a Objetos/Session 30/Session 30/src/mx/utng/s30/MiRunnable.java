package mx.utng.s30;

import java.util.concurrent.TimeUnit;

public class MiRunnable implements Runnable{
    //Atributos
    private String parametro;
    private String nombre;
 
    //Constructor
    public MiRunnable(String nombre) {
        this.nombre = nombre;
    }

    //Setters de parametro
    public void setParametro(String parametro) {
        this.parametro = parametro;
    }

    //Metodo sobreescrito de la interfaz Runnable
    @Override
    public void run() {
        while (!"terminar".equals(parametro)) {
            mostrarInformacion();
            pausarUnSegundo();
        }
        mostrarInformacion();
    }

    //Pausa un segundo la ejecución del hilo
    public static void pausarUnSegundo() {
        try{
                TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
                e.printStackTrace();
        }
    }

    private void mostrarInformacion(){
        System.out.println("Hilo: " + nombre + "\t| Parametro: " + parametro);
    }


}
