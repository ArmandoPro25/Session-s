package testdb.src.main.java.mx.utng.s23.testdb.model;

public enum Type {
    WATER,
    FIRE,
    GROUNG,
    GRASS,
    PSYCHIC,
    POISON,
    STEEL,
    ROCK,
    GHOST,
    ICE
}

