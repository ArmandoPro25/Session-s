package testdb.src.main.java.mx.utng.s23.testdb.model;


public class Trainer {
 
    @GeneratedValue(strategy = GenerationType.Auto)
    private long id;
@Column(nullable = false, length = 50)
    private String name;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

}
