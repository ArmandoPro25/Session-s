package mx.utng.ss17;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reto{
    public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("C:\\Users\\ruano\\OneDrive\\Documents\\poema.txt"); 
         //Establecemos la ruta del archivo

           
    BufferedWriter bw = new BufferedWriter(fw);
         bw.write("Te he dicho que te amo;\n" + //
                      "Pero nunca te he explicado porque;\n" + //
                      "Te amo porque abrazas la versión.\n" + //
                      "más vulnerable de mi.\n" + //
                      "Te amo porque no tienes miedo\n" + //
                      "de demostrar lo que sientes;\n" + //
                      "Te amo porque cuando mas te necesite\n" + //
                      "estuviste ahí.");
                      
 bw.newLine();
            bw.write("");
            bw.newLine();
            bw.close();

            
            FileReader fr = new FileReader("C:\\Users\\ruano\\OneDrive\\Documents\\poema.txt");  
            //Colocamos la ruta del archivo
            BufferedReader br = new BufferedReader(fr);

            String linea = null;

            while ((linea = br.readLine())!=null) {
                System.out.println(linea);
            }
    }
}
