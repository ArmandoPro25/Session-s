package mx.utng.s29.s29;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S29ApplicationTests {

	@Test
	void contextLoads() {
	}

}
