package mx.utng.s29.s29;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S29Application {

	public static void main(String[] args) {
		SpringApplication.run(S29Application.class, args);
	}

}
