package mx.utng.ss08;

public class Fabrica {
    public static void main(String[] args) {
        Automovil auto1 = new Automovil("Nissan", "Tsuru", 2005, 1200);
       
        Automovil auto2 = new Automovil("Chevrolet", "Chevy", 2000, 7500);

        Automovil auto3 = new Automovil("Ford", "Raptor", 2021, 500);

        System.out.println("auto1, hash: "+ auto1.hashCode());
        System.out.println("auto2, hash: "+ auto2.hashCode());
        System.out.println("auto3, hash: "+ auto3.hashCode());
        
        
    }
    
}
