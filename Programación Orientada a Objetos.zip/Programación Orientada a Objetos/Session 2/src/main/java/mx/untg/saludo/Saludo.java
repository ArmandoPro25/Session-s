package mx.untg.saludo;

public class Saludo {
    public static void main(String[] args) {
            System.out.println("Hola Mundo");
    }
}
