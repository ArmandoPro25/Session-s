package session;

import java.util.Scanner;

public class IntegerToBniary {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Tecle el numero que deseas tener en binario: ");
        int miNumero = s.nextInt();
        s.close();
        String binario = Integer.toBinaryString(miNumero);
        System.out.printf("El numero %d es en binario %s%n", miNumero, binario);
    }
}