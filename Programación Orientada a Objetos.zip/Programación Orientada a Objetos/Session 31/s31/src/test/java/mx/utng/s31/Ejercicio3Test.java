package mx.utng.s31;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Ejercicio3Test {
    private final List<Integer> CONJUNTO = Arrays.asList(1, 4, 6, 2, -5, 9);
    @Test
@DisplayName("Prueba para transformar a cuadrado")
    void canTransformSquare() {

        Ejercicio3 e3 = new Ejercicio3();

        List<Integer> real = e3.transformar(CONJUNTO, s -> s*s);

        assertThat(real).containsExactly(1, 4, 6, 2, 5, 9);
    }
@Test @DisplayName("Prueba para transformar y sumar")
    void canTransformAndAdd(){
        Ejercicio3 e3 = Ejercicio3();

        Integer real = e3.transformarYSumar(CONJUNTO, s-> 1);

        assertThat(real).isEqualsTo(CONJUNTO.size());
    }

}
