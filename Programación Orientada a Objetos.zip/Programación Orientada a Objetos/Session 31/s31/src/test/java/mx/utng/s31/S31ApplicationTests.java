package mx.utng.s31;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S31ApplicationTests {

	@Test
	void contextLoads() {
	}

}
