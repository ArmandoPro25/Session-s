package mx.utng.s31;


import java.util.function.Function;

public class Ejercicio3 {
    Integer transformarYSumar(Iterable<Integer> conjunto, 
    Function<Integer, Integer> funcion) {
        Integer acumulador = 0;


        for (Integer value : conjunto) {
            acumulador += funcion.apply(value);
        }

        return acumulador;
    }
}
