package mx.utng.s31;

public interface StringToInteger {

        Integer convertir(String s);

}
