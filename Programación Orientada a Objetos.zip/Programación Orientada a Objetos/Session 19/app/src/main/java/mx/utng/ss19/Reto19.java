package mx.utng.ss19;

public class Reto19 {
    public static void main(String[] args) {
        //Declaramos suma como entero
        int suma = 0;
        //Utilizamos el for int para realizar la suma de los primeros 100 numeros
        for(int i=1; i<=100; i ++){
            suma += i;
}       //Por ultimo imprimimos la suma para la suma
        System.out.println("La suma de los primeros 100 numeros es: "+ suma);
    }
}
        //En build.gradle despues de "mainClass =" colocamos la ruta del archivo
        //(Reto.java):    ('mx.utng.ss19.Reto19')