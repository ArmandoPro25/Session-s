package mx.utng.ss19;

public class AdultoMayor {
    public static void main(String[] args) {
        Gobierno.getGobierno().darApoyo();
    }
}
