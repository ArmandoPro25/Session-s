package mx.utng.s13.reto13;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListaFrutas {
     public static void main(String[] args) {
        
        //Creamos nuestra lista con cada una de las frutas
        List<String> listaFrutas = new ArrayList<>();
        listaFrutas.add("Plátanos");
        listaFrutas.add("Sandía");
        listaFrutas.add("Pera");
        listaFrutas.add("Manzana");
        listaFrutas.add("Naranja");
        listaFrutas.add("Kiwi");

        // Buscamos el elemento "fruta" más pequeño alfabeticamente
        String min = Collections.min(listaFrutas);
        System.out.println("Fruta menor alfabeticamente: " + min);

        // Buscamos el elemento "fruta" más grande alfabeticamente
        String max = Collections.max(listaFrutas);
        System.out.println("Elemento alfabéticamente mayor: " + max);

        // Ordenamos nuestras frutas por orden alfabetico
        Collections.sort(listaFrutas);
        System.out.println("Lista de frutas ordenada: " + listaFrutas);

        // Buscar la fruta "Pera" y "Naranja" dentro de nuestra lista
        int posicionPera = listaFrutas.indexOf("Pera");
        int posicionNaranja = listaFrutas.indexOf("Naranja");
        System.out.println("Posición de Pera: " + posicionPera);
        System.out.println("Posición de Naranja: " + posicionNaranja);

        // Agregamos tres manzanas a nuestra lista de frutas
        listaFrutas.add("Manzana");
        listaFrutas.add("Manzana");
        listaFrutas.add("Manzana");

        // Desordenamos los elementos de la lista
        Collections.shuffle(listaFrutas);
        System.out.println("Lista de frutas desordenada: " + listaFrutas);

        // Contamos cuantas manzanas hay en total
        long cantidadManzanas = listaFrutas.stream().filter(fruta -> fruta.equals("Manzana")).count();
        System.out.println("Cantidad de Manzanas: " + cantidadManzanas);

     }
}
