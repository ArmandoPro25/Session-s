package mx.utng.s13.ej2;

public class Numero {
    private String nombre;
    public Numero(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
