package mx.utng.s13.ej2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Colecciones {
    public static void main(String[] args) {
        //Lista de cadenas
        List<String> listaCadenas = new ArrayList<>();
        listaCadenas.add("uno");
        listaCadenas.add("dos");
        listaCadenas.add("tres");
        listaCadenas.add("cuatro");
        listaCadenas.add("cinco");
        
        System.out.println("..........fori..........");
        for (int i = 0; i < listaCadenas.size(); i++){
            System.out.printf("%s%n", listaCadenas.get(i));
        }
        
        System.out.println("..........foreach.........");
        for (String string : listaCadenas){
            System.out.println(string);
        }

        //Conjunto de cadenas
        Set<String> setCadenas = new HashSet<>();
        setCadenas.add("uno");
        setCadenas.add("dos");
        setCadenas.add("tres");
        setCadenas.add("cuatro");
        setCadenas.add("cinco");

        //Foreach para imprimir los valores
        System.out.println("---------SET DE CADENAS----------");
        for (String cadena : setCadenas) { 
            System.out.println(cadena);
        }


        List<Numero> listaNumeros = new ArrayList<>();
        listaNumeros.add(new Numero("Uno"));
        listaNumeros.add(new Numero("Dos"));
        listaNumeros.add(new Numero("Dos"));
        listaNumeros.add(new Numero("Tres"));
        listaNumeros.add(new Numero("Cuatro"));
        listaNumeros.add(new Numero("Cinco"));

        //Foreach para imprimir los valores
        System.out.println("*********** LISTA DE NUMEROS ***********");
        for (Numero nuemro : listaNumeros) {
            System.out.println(nuemro.getNombre());
        }

        Set<Numero> setNumeros = new HashSet<>();
        setNumeros.add(new Numero("Uno"));
        setNumeros.add(new Numero("Dos"));
        setNumeros.add(new Numero("Dos"));
        setNumeros.add(new Numero("Tres"));
        setNumeros.add(new Numero("Cuatro"));
        setNumeros.add(new Numero("Cinco"));
     
        //Foreach para imprimir los valores 
        System.out.println("*********** SET DE NUMEROS **************");
        for (Numero numero : setNumeros) {
            System.out.println(numero.getNombre());
        }

    }


    
}
