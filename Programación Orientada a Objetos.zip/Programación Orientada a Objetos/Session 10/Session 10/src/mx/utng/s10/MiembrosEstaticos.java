package mx.utng.s10;

public class MiembrosEstaticos {
    public static void main(String[] args) {
        Contador contador1 = new Contador();
        Contador contador2 = new Contador();
        Contador contador3 = new Contador();
        Contador contador4 = new Contador();
        System.out.println("Contador.contadorClase: "+
                            contador1.getContadorClase());
        System.out.printf("contador1.contadorInstancia: %d %n",
                            contador1.getContadorInstancia());
    }
}
