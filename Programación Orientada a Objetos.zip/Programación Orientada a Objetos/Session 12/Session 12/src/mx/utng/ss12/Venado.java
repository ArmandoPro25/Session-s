package mx.utng.ss12;

public class Venado extends Animal implements Hervivoro {
    
}
