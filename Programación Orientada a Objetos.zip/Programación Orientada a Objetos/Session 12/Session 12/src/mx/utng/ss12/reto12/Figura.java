package mx.utng.ss12.reto12;

public abstract class Figura {

    
    
}
