package mx.utng.ss12;

public interface Hervivoro {
    
}
