package mx.utng.ss12.reto12;

public class PruebaFigura {
    public static void main(String[] args) {
        Figura figura;
    }
}
