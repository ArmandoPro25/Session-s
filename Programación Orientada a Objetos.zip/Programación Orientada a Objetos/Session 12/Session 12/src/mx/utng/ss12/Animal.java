package mx.utng.ss12;

public abstract class Animal {
    
}
