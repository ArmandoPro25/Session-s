package mx.utng.ss12.reto12;
/**
 * @autor: arm
 * @date: 06/02/24
 **/

public interface Triangulo {

  public static void main(String[] args) {
  private double base;
  private double altura;


  }

  public void calcularArea(double base, double altura);
  

  }
   
