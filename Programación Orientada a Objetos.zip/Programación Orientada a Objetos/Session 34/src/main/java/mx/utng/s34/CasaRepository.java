package mx.utng.s34;

public interface CasaRepository extends CrudRepository<Casa, Long> {
    

}
