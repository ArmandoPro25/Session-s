package mx.utng.s34;

import java.util.ArrayList;

import javax.print.attribute.standard.RequestingUserName;

public class TodaLogica {
    private final CasaRepository repository;

    @Autowired
    public TodaLogica(CasaRepository repository) {
        this.repository = repository
    }

    @RequestMapping(value = "", methos = RequestMethod.POST)
    public void guardarCasa(@RequestBody Casa casa){
        if (casa.getJefeDeFamilia() == null) {
            throw RuntimeException("Se debe detener un jefe de Familia")
            
        }

        casa.setJefeDeFamilia(casa.getJefeDeFamilia().toUpperCase());

        ArrayList<String> otrosMayusculas = new ArrayList<>();

        for (String nombre : otrosMayusculas) {
            otrosMayusculas.add(nombre.toUpperCase());
        }
    
        casa.setOtros(otrosMayusculas);

        repository.save(casa);
    }

}
